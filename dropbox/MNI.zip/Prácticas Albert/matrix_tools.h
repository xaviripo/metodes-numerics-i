/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   matrix_tools.h
 * Author: Miquel
 *
 * Created on 8 de noviembre de 2016, 21:45
 */

#ifndef MATRIX_TOOLS_H
#define MATRIX_TOOLS_H

#include<time.h>
#include<stdio.h>
#include<stdlib.h>

/* Devuelve un vector vacÃ­o de tamaÃ±o n */
double * vector_alloc(int n) {
    double *v;

    v = (double*) malloc(n * sizeof(double));
    if (v == NULL) { 
	    printf("Error allocating vector.\n"); exit(1);
    }
    return v;
}

/* Devuelve una matriz de tamaÃ±o nxm */
double ** matrix_alloc(int n, int m) {
    int i;
    double **A;

    A = (double**) malloc(n*sizeof(double));
    if (A == NULL) { 
	    printf("Error allocating matrix.\n"); exit(1);
    }
    for (i = 0; i < n; i++) {
        A[i] = vector_alloc(m);
    }
    return A;
}

/* Lee por consola los valores de un vector */
void vector_read(int n, double * v) {
    int i;

    for (i = 0; i < n; i++) {
        scanf("%lf", v+i);     
    }
}

/* Lo mismo pero para matrices */
void matrix_read(int m, int n, double **M) {
    int i, j;

    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
            scanf("%lf", (M[i]) +j);
        }
    }
}

/* Imprime un vector de integers */
void vector_write_int(int n, int *v) {
    int i;

    for (i = 0; i<n; i++) {
        printf("%d ", v[i]);
    }
    printf("\n");
}

/* Imprime un vector de doubles */
void vector_write(int n, double *v) {
    int i;

    for (i = 0; i<n; i++) {
        printf("%lf ", v[i]);
    }
    printf("\n");
}

void matrix_write(int n, int m, double **M) {
    int i, j;

    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("%le\t", M[i][j]);
        }
        printf("\n");
    }
}

/* permuta las filas i, j de una matriz y 
 * devuelve 1 o 0 en funcion de si permuta
 * o no */
int permuta_files(int i, int j, double **A) {
    /* permuta les files i i j de la matriu A*/
    double *temp;

    if (i == j) return 0; /* retorna 0 si no cal permutar */

    temp = A[i];
    A[i] = A[j];
    A[j] = temp;

    return 1;
}

/* suma la fila i multiplicada por m a la j */
void suma_files(int i, int j, double m, int n, double **A) {
    /* suma la fila i multiplicada per m  a la fila j.
     * n fa referencia a la llargada de les files
     */
    int k;
    double * fi;
    double * fj;

    fi = A[i];
    fj = A[j];
    for (k = 0; k < n; k++) {
        fj[k] += m * fi[k];
    }
}

/* crea una matriz con coeficientes aleatorios */
double ** random_matrix(int n, int m, double min, double max) {
    int i, j;
    double **A;
    srand(time(NULL)); 
    A = matrix_alloc(n,m);

    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
	    A[i][j] = (max - min)*((double)rand()/RAND_MAX) + min;
        }
    }
	
    return A;
}	


#endif /* MATRIX_TOOLS_H */

